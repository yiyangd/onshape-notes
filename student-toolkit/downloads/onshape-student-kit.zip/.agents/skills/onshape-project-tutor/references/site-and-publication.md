# 项目目录、本地播放和发布

把课程维护为可搬动的静态文件。下面用一门新课举例，其他模型使用各自的英文小写短名。

```text
site/
  index.html
  pyramid/
    index.html
    media/
      01.gif
      02.gif
```

首页放模型名称和能打开教程的项目卡。使用同一个工程里的网址前缀，避免写死学生的硬盘路径、域名或教师的仓库名。项目页的动图引用 media/01.gif。返回目录用 ../index.html，发布后亦可用 ../。项目课可链接到 #step-09 这样的具体步骤。

**英文起始页和双语按钮。** 首页和每个教程都设 `<html lang="en">`。英文及媒体随静态 HTML 提供。中文紧跟对应英文，用 `class="zh" lang="zh-CN"` 标记，默认用 CSS 隐藏。双语模式将每段中文显示为独立的一行。沿用现有站点共用的语言脚本、样式和偏好键；新站也让所有页面共用它们。页首提供原生 `button type="button"`，固定标签为 **Bilingual · 双语**。用 `aria-pressed` 表示开关状态；学生可用鼠标、触屏、Enter 或空格开关。记住选择，并在访问另一页或刷新时恢复。存储不可用时，本页仍能切换。仅在脚本可用时显示按钮，关闭脚本时照常阅读英文和打开 GIF。将脚本、样式和媒体一并放入本地包。

新建网站时，可将随附的 [language.css](../assets/language.css) 和 [language.js](../assets/language.js) 复制到网站根目录。首页用 `language.css`、`language.js`，项目子页在两个路径前加 `../`。以下分别是首页的资源引入、各页共用的按钮和教程中一对操作说明。

```html
<!-- 放在 head 中 -->
<link rel="stylesheet" href="language.css">
<script defer src="language.js"></script>
<!-- 放在每一页的页首 -->
<button id="bilingual-toggle" type="button" aria-pressed="false" hidden>
  <span class="track" aria-hidden="true"></span>
  <span>Bilingual · <span lang="zh-CN">双语</span></span>
</button>
<!-- 放在对应步骤内，动图上方 -->
<p>Click the center of the Origin.</p>
<p class="zh" lang="zh-CN">点击 Origin 靶心的正中心。</p>
```

**动图、配图和放大链接。** 同一张英文 Onshape 录屏可以在两种模式共用，翻译放在图旁的可切换图注里。若动图或示意图已嵌入中文标注，提供相同操作、鼠标落点和时序的英文版，开启双语后再显示原双语版。Word 可嵌入同一步的共用动图或双语版。以下例子将动图及放大链接一起切换。使用随附语言脚本时，把这段内联脚本放在项目页末尾，使它能收到初次恢复偏好以及后续切换的事件。

```html
<a href="media/09-en.gif" data-bilingual-file="media/09-bilingual.gif">
  <img src="media/09-en.gif" data-bilingual-file="media/09-bilingual.gif" alt="Click the center of the Origin">
</a>
<script>
  const pairedMedia = Array.from(document.querySelectorAll('[data-bilingual-file]'), element => {
    const attribute = element.tagName === 'IMG' ? 'src' : 'href';
    return {element, attribute, english: element.getAttribute(attribute)};
  });
  document.addEventListener('onshape-language-change', ({detail: bilingual}) => {
    for (const {element, attribute, english} of pairedMedia) {
      const file = bilingual ? element.dataset.bilingualFile : english;
      if (element.getAttribute(attribute) !== file) element.setAttribute(attribute, file);
    }
  });
</script>
```

**本地双击与在线干净网址。** 本地 file: 页面直接打开明确的 index.html，在线则让点击后的地址形如 /仓库名/pyramid/。可以用以下写法给目录链接与“返回目录”链接做渐进增强。在对应页面末尾执行脚本，选择器只处理你声明的链接。关闭脚本时，显式 HTML 文件链接仍能打开课程。

```html
<!-- 项目目录 -->
<a href="pyramid/index.html" data-web-path="pyramid/">Pyramid<span class="zh" lang="zh-CN">四棱锥</span></a>
<!-- 项目内的返回链接 -->
<a href="../index.html" data-web-path="../">Projects<span class="zh" lang="zh-CN">项目目录</span></a>
<script>
  if (location.protocol === 'https:' || location.protocol === 'http:') {
    for (const link of document.querySelectorAll('a[data-web-path]')) {
      link.setAttribute('href', link.dataset.webPath);
    }
  }
</script>
```

**已有网站。** 先检查仓库当前内容、已有目录、发布分支或工作流。添加这次指定的项目和目录入口。若旧首页原本是一门课，移动内容时同时修正相对媒体链接；已发出的旧步骤链接应指向原来的课程步骤。普通根网址应一直显示项目目录。

**实际走一次学生的路线。** 解压本地包，双击首页，点项目卡、查看一个 GIF、返回目录。若已发布，等 GitHub Pages 完成本次部署，以匿名浏览器从正式根网址进入；点击卡片后读取地址栏，再测试步骤链接。用实际可访问的网址交付。已有标签页仍显示旧页面时，重新加载该页并再点一次验证。
