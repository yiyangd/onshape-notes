# 项目目录、本地播放和发布

把课程维护为可搬动的静态文件。下面用一门新课举例，其他模型使用各自的英文小写短名。

```text
site/
  index.html
  pyramid/
    index.html
    media/
      01.gif
      02.gif
```

首页放模型名称和能打开教程的项目卡。使用同一个工程里的网址前缀，避免写死学生的硬盘路径、域名或教师的仓库名。项目页的动图引用 media/01.gif。返回目录用 ../index.html，发布后亦可用 ../。项目课可链接到 #step-09 这样的具体步骤。

**本地双击与在线干净网址。** 本地 file: 页面直接打开明确的 index.html，在线则让点击后的地址形如 /仓库名/pyramid/。可以用以下写法给目录链接与“返回目录”链接做渐进增强。在对应页面末尾执行脚本，选择器只处理你声明的链接。关闭脚本时，显式 HTML 文件链接仍能打开课程。

```html
<!-- 项目目录 -->
<a href="pyramid/index.html" data-web-path="pyramid/">Pyramid · 四棱锥</a>
<!-- 项目内的返回链接 -->
<a href="../index.html" data-web-path="../">Projects · 项目目录</a>
<script>
  if (location.protocol === 'https:' || location.protocol === 'http:') {
    for (const link of document.querySelectorAll('a[data-web-path]')) {
      link.setAttribute('href', link.dataset.webPath);
    }
  }
</script>
```

**已有网站。** 先检查仓库当前内容、已有目录、发布分支或工作流。添加这次指定的项目和目录入口。若旧首页原本是一门课，移动内容时同时修正相对媒体链接；已发出的旧步骤链接应指向原来的课程步骤。普通根网址应一直显示项目目录。

**实际走一次学生的路线。** 解压本地包，双击首页，点项目卡、查看一个 GIF、返回目录。若已发布，等 GitHub Pages 完成本次部署，以匿名浏览器从正式根网址进入；点击卡片后读取地址栏，再测试步骤链接。用实际可访问的网址交付。已有标签页仍显示旧页面时，重新加载该页并再点一次验证。
