"""Check a local Onshape lesson before opening it in Word and a browser.

Python 3.8+. Uses local files only. A step is a container with id="step-01",
etc. Use data-media="still" on a step for an explicitly labeled screenshot.
The Word file should embed the same lesson images in the same sequence.
"""

import argparse
import hashlib
import posixpath
import re
import sys
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlsplit
from xml.etree import ElementTree as ET
from zipfile import ZipFile, BadZipFile


class LessonPage(HTMLParser):
    void = set("area base br col embed hr img input link meta param source track wbr".split())

    def __init__(self, file):
        super().__init__()
        self.stack = []
        self.links = []
        self.images = []
        self.steps = []
        self.feed(file.read_text(encoding="utf-8-sig"))
        self.close()

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        active = self.stack[-1][1] if self.stack else None
        if re.fullmatch(r"step-\d+", attrs.get("id", "")):
            active = (attrs["id"], attrs.get("data-media") == "still", [])
            self.steps.append(active)
        if tag == "a" and attrs.get("href"):
            self.links.append(attrs["href"])
        if tag == "img":
            source = attrs.get("src") or ""
            self.images.append(source)
            if active is not None:
                active[2].append(source)
        if tag not in self.void:
            self.stack.append((tag, active))

    def handle_endtag(self, tag):
        for index in range(len(self.stack) - 1, -1, -1):
            if self.stack[index][0] == tag:
                del self.stack[index:]
                break


def local_target(root, page, reference):
    """Resolve portable relative URLs and check exact case even on Windows."""
    url = urlsplit(reference)
    path = unquote(url.path)
    if url.scheme or url.netloc or not path or path.startswith("/"):
        return None
    where = page.parent.relative_to(root).as_posix()
    rel = posixpath.normpath(posixpath.join(where, path))
    if rel == ".." or rel.startswith("../") or "\\" in rel:
        raise ValueError(f"{page.name}: URL leaves the site or has a backslash: {reference}")
    target = root
    for part in Path(rel).parts:
        if not target.is_dir() or part not in {p.name for p in target.iterdir()}:
            raise ValueError(f"Missing local URL or incorrect filename case: {reference} ({page.name})")
        target = target / part
    if target.is_dir():
        target = target / "index.html"
    if not target.is_file():
        raise ValueError(f"Missing local file: {target}")
    return target


def gif_timing(data):
    """Walk the GIF stream, counting image descriptors and their control delays."""
    if len(data) < 13 or data[:6] not in (b"GIF87a", b"GIF89a"):
        raise ValueError("Not a GIF")
    def table_size(flags):
        return 3 * (2 << (flags & 7)) if flags & 128 else 0

    offset = 13 + table_size(data[10])
    delays = []
    delay = 0
    while offset < len(data):
        kind = data[offset]
        offset += 1
        if kind == 0x3B:
            return delays
        if kind == 0x21:                     # Extension: label plus data blocks
            if offset >= len(data):
                break
            label = data[offset]
            offset += 1
            if label == 0xF9:
                if offset + 5 >= len(data) or data[offset] != 4:
                    break
                delay = int.from_bytes(data[offset + 2:offset + 4], "little") * 10
            elif label == 0x01:             # Plain text also consumes a control block
                delay = 0
        elif kind == 0x2C:                   # Image, optional local palette, LZW size
            if offset + 9 >= len(data):
                break
            offset += 10 + table_size(data[offset + 8])
            delays.append(delay)
            delay = 0
        else:
            break
        while offset < len(data):
            size = data[offset]
            offset += 1
            if size == 0:
                break
            offset += size
    raise ValueError("Truncated or invalid GIF stream")


def word_images(docx):
    """Read only drawings present in the main document, in body order."""
    rid = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
    with ZipFile(docx) as z:
        relationships = ET.fromstring(z.read("word/_rels/document.xml.rels"))
        image_paths = {}
        for rel in relationships:
            if rel.get("Type", "").endswith("/image") and rel.get("TargetMode") != "External":
                target = unquote(rel.attrib["Target"])
                joined = target[1:] if target.startswith("/") else posixpath.join("word", target)
                image_paths[rel.attrib["Id"]] = posixpath.normpath(joined)
        main = ET.fromstring(z.read("word/document.xml"))
        cache = {}
        for node in main.iter():
            name = node.tag.rsplit("}", 1)[-1]
            if name not in ("blip", "imagedata"):
                continue
            key = node.get(rid + ("embed" if name == "blip" else "id"))
            if key in image_paths:
                part = image_paths[key]
                if part not in cache:
                    cache[part] = hashlib.sha256(z.read(part)).digest()
                yield cache[part]


def verify(root, slug, docx):
    if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", slug):
        raise ValueError("--project expects one lowercase project slug, e.g. traffic-cone")
    root = root.resolve()
    home = root / "index.html"
    lesson = root / slug / "index.html"
    hub = LessonPage(home)
    page = LessonPage(lesson)
    if hub.steps:
        raise ValueError("The project directory contains lesson steps")
    for location, parsed, destination in ((home, hub, lesson), (lesson, page, home)):
        paths = [local_target(root, location, url) for url in parsed.links]
        if destination not in paths:
            raise ValueError(f"No relative navigation link from {location} to {destination}")
        for url in parsed.images:
            local_target(root, location, url)
    if not page.steps:
        raise ValueError("No step containers found")

    embedded = list(word_images(docx))
    start = 0
    for number, (step_id, still, images) in enumerate(page.steps, 1):
        if step_id != f"step-{number:02d}":
            raise ValueError(f"Expected step-{number:02d}, found {step_id}")
        allowed = (".jpg", ".jpeg", ".png", ".webp") if still else (".gif",)
        media = [local_target(root, lesson, url) for url in images
                 if unquote(urlsplit(url).path).lower().endswith(allowed)]
        assets = [p for p in media if p is not None]
        if not assets:
            raise ValueError(f"{step_id}: missing local {'still image' if still else 'GIF'} inside step")
        payload = assets[0].read_bytes()
        if not still:
            try:
                frames = gif_timing(payload)
            except ValueError as error:
                raise ValueError(f"{step_id}: {error}") from error
            duration = sum(frames)
            if len(frames) < 2 or duration == 0:
                raise ValueError(f"{step_id}: GIF has no timed animation")
            if not 1000 <= duration <= 2000:
                print(f"Note: {step_id} runs for {duration / 1000:.2f} seconds")
        try:
            start = embedded.index(hashlib.sha256(payload).digest(), start) + 1
        except ValueError as error:
            raise ValueError(f"{step_id}: could not find matching embedded image bytes "
                             "in the DOCX in lesson order. Check for recompression or a missing image.") from error
    print(f"Verified local navigation and {len(page.steps)} ordered web/Word step images.")
    print("Open the web page and Word to check the actual click targets, text and playback.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--site", type=Path, required=True, help="directory containing the project catalog index.html")
    parser.add_argument("--project", required=True, help="lesson directory slug, e.g. pyramid")
    parser.add_argument("--docx", type=Path, required=True, help="bilingual Word lesson")
    args = parser.parse_args()
    try:
        verify(args.site, args.project, args.docx)
    except (OSError, BadZipFile, KeyError, ValueError, ET.ParseError) as error:
        print(f"Check failed: {error}", file=sys.stderr)
        sys.exit(1)
